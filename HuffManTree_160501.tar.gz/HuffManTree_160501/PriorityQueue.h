/*
PriorityQueue.h
*/
#ifndef _PRIORITYQUEUE_H_
#define _PRIORITYQUEUE_H_
//-------------
#include"app.h"
//-----------
typedef struct xPriorityQueue
{
	int m_ncount;//优先级队列容器的最大容量；
	int m_size;//优先级队列容器内当前的元素个数；
	int* m_pv;//优先级队列容器内的元素；
}PriorityQueue,*PPriorityQueue;
//本项目内要用的数据结构；
typedef struct xData
{
	int m_index1;
	int m_index2;
	int* m_pv;
}Data,*PData;
//--------
int Compare(void* pt);
void InitPriorityQueue(const PPriorityQueue ppq,int ncount);
void DestroyPriorityQueue(const PPriorityQueue ppq);
//加入优先级队列：
int EnterPriorityQueue(const PPriorityQueue ppq,int v,void* pt,int (*pComp)(void*));
//出队：
int ExitPriorityQueue(const PPriorityQueue ppq,int* pv,void* pt,int (*pComp)(void*));
//--------------
#endif//_PRIORITYQUEUE_H_
//------------



