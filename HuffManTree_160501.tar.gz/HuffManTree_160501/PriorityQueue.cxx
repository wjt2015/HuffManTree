/*
PriorityQueue.cxx
*/
//------
#include"PriorityQueue.h"
//-----------
int Compare(void* pt)
{
	int iret=0;
	PData pd=(PData)pt;
	if(pd->m_pv[pd->m_index1]<pd->m_pv[pd->m_index2])
		iret=-1;
	else if(pd->m_pv[pd->m_index1]>pd->m_pv[pd->m_index2])
		iret=1;
	return iret;
}
//--
void InitPriorityQueue(const PPriorityQueue ppq,int ncount)
{
	if(ppq!=NULL&&ncount>=1)
	{
		memset(ppq,0,sizeof(PriorityQueue));
		ppq->m_ncount=ncount;
		ppq->m_pv=(int*)calloc(ncount,sizeof(int));
	}
}
void DestroyPriorityQueue(const PPriorityQueue ppq)
{
	if(ppq!=NULL)
	{
		if(ppq->m_pv!=NULL)
			free(ppq->m_pv);
		memset(ppq,0,sizeof(PriorityQueue));
	}
}
//----
//添加节点后调整：
void UpAdjust(int* pv,int iend,void* pt,int (*pComp)(void*))
{
	if(pv!=NULL&&iend>=1)
	{
		int i=0,j=0,tempt=pv[iend];
		PData pd=(PData)pt;
		pd->m_index1=tempt;
		for(j=i=iend;i>=1;j=i)
		{
			i=(i-1)/2;
			pd->m_index2=pv[i];
			if((*pComp)(pd)<0)
				pv[j]=pv[i];
			else
				break;
		}
		pv[j]=tempt;
	}
}
//----
//删除节点后调整：
void DownAdjust(int* pv,int iend,void* pt,int (*pComp)(void*))
{
	if(pv!=NULL&&iend>=1)
	{
		int i,j,lchildID,rchildID,tempt=pv[0];
		PData pd=(PData)pt;
		for(i=0;(j=lchildID=2*i+1)<=iend;i=j)
		{
			if((rchildID=lchildID+1)<=iend)
			{
	           pd->m_index1=pv[lchildID];
			   pd->m_index2=pv[rchildID];
			   if((*pComp)(pd)>0)
				   j=rchildID;
			}
			pd->m_index1=tempt;
			pd->m_index2=pv[j];
			if((*pComp)(pd)>0)
				pv[i]=pv[j];
			else
				break;
		}
		pv[i]=tempt;
	}
}
//----
//加入优先级队列：
int EnterPriorityQueue(const PPriorityQueue ppq,int v,void* pt,int (*pComp)(void*))
{
	int iret=_FAIL_;
	if(ppq!=NULL&&ppq->m_size<ppq->m_ncount)
	{
		iret=_SUCCESS_;
		ppq->m_pv[ppq->m_size]=v;
		ppq->m_size++;
		//调整：
               UpAdjust(ppq->m_pv,ppq->m_size-1,pt,pComp);
		//------
	}
	return iret;
}
//---
//出队：
int ExitPriorityQueue(const PPriorityQueue ppq,int* pv,void* pt,int (*pComp)(void*))
{
	int iret=_FAIL_;
	if(ppq!=NULL&&ppq->m_size>0)
	{
		iret=_SUCCESS_;
               if(pv!=NULL)
			*pv=ppq->m_pv[0];
		ppq->m_size--;
		if(ppq->m_size>0)
		   ppq->m_pv[0]=ppq->m_pv[ppq->m_size];
		//调整；
                DownAdjust(ppq->m_pv,ppq->m_size-1,pt,pComp);
	}
	return iret;
}
//-------------







