/*
HuffManTree.cxx
*/
#include"HuffManTree.h"
//------------
/*
给定数据，计算哈夫曼树：
pTree!=NULL;
int Compare(void* pt)
*/
//--------------
//构造哈夫曼树：
void ConstructHuffManTree(PHuffManTree pTree)
{
  if(pTree!=NULL&&pTree->m_ncount>=1&&pTree->m_leftID!=NULL&&pTree->m_rightID!=NULL&&pTree->m_parentID!=NULL)
  {
    int i,leftID,rightID,iend=2*pTree->m_ncount-2;
	Data data={0,0,pTree->m_pw};
	PriorityQueue pq;
	InitPriorityQueue(&pq,pTree->m_ncount);
    for(i=0;i<pTree->m_ncount;++i)
       EnterPriorityQueue(&pq,i,&data,Compare);
	for(i=pTree->m_ncount;i<=iend;++i)
	{
         //选择两个权最小且无父的节点；
	  ExitPriorityQueue(&pq,&leftID,&data,Compare);
	  ExitPriorityQueue(&pq,&rightID,&data,Compare);
	  //------
	  pTree->m_leftID[i]=leftID;
	  pTree->m_rightID[i]=rightID;
	  pTree->m_pw[i]=pTree->m_pw[leftID]+pTree->m_pw[rightID];
	  pTree->m_parentID[leftID]=pTree->m_parentID[rightID]=i;
	  //将i加入待选集；
      EnterPriorityQueue(&pq,i,&data,Compare);
	}
    DestroyPriorityQueue(&pq);
  }
}
//------------
//根据构造出的哈夫曼树为每个字符编码；
void Encode(const PHuffManTree pTree)
{
   if(pTree!=NULL)
   {
      //pTree->m_ppcode=(char**)calloc(pTree->m_ncount,sizeof(char*));
      char* ptcode=(char*)calloc(pTree->m_ncount,sizeof(char));
      int cur_ID,tcur_ID,parent_ID,istart,n;
      const int iend=pTree->m_ncount-1;
      ptcode[iend]='\0';
      for(cur_ID=0;cur_ID<pTree->m_ncount;++cur_ID)
      {
          for(tcur_ID=cur_ID,istart=iend;(parent_ID=pTree->m_parentID[tcur_ID])>=pTree->m_ncount;tcur_ID=parent_ID)
          {
              --istart;
              if(tcur_ID==pTree->m_leftID[parent_ID])
                   ptcode[istart]='0';
              else
                   ptcode[istart]='1';
          }
           n=pTree->m_ncount-istart;
           pTree->m_ppcode[cur_ID]=(char*)calloc(n,sizeof(char));
           memcpy(pTree->m_ppcode[cur_ID],ptcode+istart,n);
      }
      free(ptcode);
   }
}
//----------
/*根据一个给定的0-1字符串译码，若成功，返回相应字符在pTree->m_pc数组内的下标，
否则，返回失败原因；*/
int Decode(const PHuffManTree pTree,char* pbuff,int* pncount)
{
    int iret=-1;
    if(pTree!=NULL&&pbuff!=NULL&&pncount!=NULL&&*pncount>0)
    {
        int i,cur_ID,child_ID;
        const int ncount=*pncount;
        for(i=0,cur_ID=2*pTree->m_ncount-2;i<ncount&&cur_ID>=pTree->m_ncount&&iret==-1;++i,cur_ID=child_ID)
        {
            switch(pbuff[i])
            {
             case '0':
                   child_ID=pTree->m_leftID[cur_ID];
                   break;
             case '1':
                   child_ID=pTree->m_rightID[cur_ID];
                   break;
             default:
                   iret=-2;
                   break;
            }
        }
        *pncount=i;
        if(cur_ID<pTree->m_ncount)
            iret=cur_ID;
        else if(i>=ncount)
            iret=_NOENOUGH_;
        else
            iret=_ILLEGALCODE_;
    }
     return iret;
}
//-------
/*
从文件infname内读取0-1串，译码,并将结果写入文件outfname内；
*/
void TextDecode(const PHuffManTree pTree,const char infname[],const char outfname[])
{
    if(pTree!=NULL)
    {
        char buff[_NBUFFSIZE_];
        int iret=0,i=0,buff_capacity=0,buff_istart=0,buff2_istart=0,buff2_used_ncount=0,buff2_available_ncount=0;
        int copy_ncount=0,buff2_decode_istart=0,spare_buff2_ncount=0;
        const int iend=_NBUFFSIZE_-1,buff2_capacity=pTree->m_ncount;
        memset(buff,0,_NBUFFSIZE_*sizeof(char));;
        size_t n=0;
        ssize_t nret=0;
        char* pc=NULL;
        char* pbuff=NULL;
        char* pbuff2=(char*)calloc(buff2_capacity,sizeof(char));
       FILE* infp=fopen(infname,"r");
       FILE* outfp=fopen(outfname,"w");
       //--------
       for(i=0,buff2_istart=0;(nret=getline(&pbuff,&n,infp))>0;)
       {
            if((pc=strchr(pbuff,'\n'))!=NULL)//剔除'\n';
            {
                *pc='\0';
                nret=pc-pbuff;//pbuff内的可译码的元素个数；
            }
            for(buff_istart=0,buff_capacity=nret;buff_istart<buff_capacity;buff_istart+=copy_ncount)
            {
                 //复制数据：pbuff2[buff2_istart,buff2_capacity)<-pbuff[buff_istart,buff_capacity);
                 copy_ncount=buff_capacity-buff_istart;
                 spare_buff2_ncount=buff2_capacity-buff2_istart;
                 if(copy_ncount>spare_buff2_ncount)
                     copy_ncount=spare_buff2_ncount;
                memcpy(pbuff2+buff2_istart,pbuff+buff_istart,copy_ncount);
                //循环读取0-1串，译码；
                buff2_decode_istart=0;
                buff2_used_ncount=buff2_available_ncount=buff2_istart+copy_ncount;//                                                                         
                for(;(iret=Decode(pTree,pbuff2+buff2_decode_istart,&buff2_used_ncount))>=0;)
                {
                    //buff[i]=(char)(iret+'A');
                   buff[i]=pTree->m_pc[iret];
                    //---------------------------
                    i++;
                    if(i==iend)
                    {
                        fprintf(outfp,"%s",buff);
                        i=0;
                        memset(buff,0,_NBUFFSIZE_*sizeof(char));//
                    }
                    //---
                    buff2_decode_istart+=buff2_used_ncount;
                    buff2_used_ncount=(buff2_available_ncount-=buff2_used_ncount);
                    //----
                }
                if(iret==_ILLEGALCODE_)
                {
                    printf("\tTextDecode();_ILLEGALCODE_;exit!!\n");
                    exit(1);//不必显式调用fflush();
                }
                else
                {
                       for(buff2_istart=0;buff2_istart<buff2_used_ncount;++buff2_istart,++buff2_decode_istart)//
                           pbuff2[buff2_istart]=pbuff2[buff2_decode_istart];
                }
            }
       }
       //---
       fprintf(outfp,"%s\n",buff);
       //----
        if(pbuff!=NULL)
        {
             free(pbuff);
             pbuff=NULL;
        }
        free(pbuff2);
       //-------
       fclose(infp);
       fclose(outfp);
       free(pbuff);
    }
}
//---------
//从文件infname内读取字符数据：
void InputCharsFromFile(const char infname[],map<char,Char_Attribute>& cmap)
{
    FILE* infp=fopen(infname,"r");
    if(infp==NULL)
    {
        printf("\tInputCharsFromFile() error;infp==NULL!!\n");
        exit(1);
    }
    //------
    int index=0;
    char* pbuff=NULL;
   char* pc=NULL;
    ssize_t nret=0,i=0;
    size_t n=0;
    for(index=0;(nret=getline(&pbuff,&n,infp))>0;)
    {//每次读取一批字符，再逐个计数；
        /*if((pc=strchr(pbuff,'\n'))!=NULL)
        {
           *pc='\0';
           nret=pc-pbuff;
        }*/
        for(i=0;i<nret;++i)
        {
            Char_Attribute& rca=cmap[pbuff[i]];
            if(rca.m_ncount==0)
                 rca.m_nIndex=index++;
            ++rca.m_ncount;
        }
    }
    //-------
    if(pbuff!=NULL)
        free(pbuff);
    fclose(infp);
}
//------------
//根据cmap提供的信息为哈夫曼树分配堆内存:
void AllocateHuffManTreeFromMap(PHuffManTree pTree,map<char,Char_Attribute>& cmap)
{
    map<char,Char_Attribute>::size_type cmap_size=cmap.size();
    if(pTree!=NULL&&cmap_size>0)
    { 
        pTree->m_ncount=(int)cmap_size;
        int i=0,n=2*pTree->m_ncount-1;
        //动态分配内存；
        int* pt=(int*)calloc(4*n,sizeof(int));
        int v=-1;
        memset(pt,v,4*n*sizeof(int));
        pTree->m_pw=pt;
        pTree->m_leftID=(pt+=n);
        pTree->m_rightID=(pt+=n);
        pTree->m_parentID=(pt+=n);
        //---
        pTree->m_pc=(char*)calloc(pTree->m_ncount,sizeof(char));
        pTree->m_ppcode=(char**)calloc(pTree->m_ncount,sizeof(char*));
        memset(pTree->m_ppcode,0,pTree->m_ncount*sizeof(char*));
        //在哈夫曼树结构体内设置字符和权值；
        map<char,Char_Attribute>::iterator it,itend=cmap.end();
        for(it=cmap.begin();it!=itend;++it)
        {
            pTree->m_pc[it->second.m_nIndex]=it->first;
            pTree->m_pw[it->second.m_nIndex]=it->second.m_ncount;
        }
   }
}
//释放哈夫曼树的堆内存:
void DestroyHuffManTreeFromMap(PHuffManTree pTree)
{
    if(pTree!=NULL)
    {
        free(pTree->m_pw);
        free(pTree->m_pc);
        int i;
        for(i=0;i<pTree->m_ncount;++i)
        {
            if(pTree->m_ppcode[i]!=NULL)
                free(pTree->m_ppcode[i]);
        }
        free(pTree->m_ppcode); 
    }
}
//----------------
//从文件infname内读取文本字符，编码，并将生成的0-1串写入文件outfname内;
void TextEncode(const PHuffManTree pTree,map<char,Char_Attribute>& cmap,const char infname[],const char outfname[])
{
    if(pTree!=NULL&&cmap.size()>0)
    {
        FILE* infp=fopen(infname,"r");
        FILE* outfp=fopen(outfname,"w");
        //-------
        char* pbuff=NULL;
       // char* pc=NULL;
        size_t n=0;
        ssize_t nret=0,i=0;
        for(;(nret=getline(&pbuff,&n,infp))>0;)
        {
            for(i=0;i<nret;++i)
            {
                 Char_Attribute& rca=cmap[pbuff[i]];
                 fprintf(outfp,"%s\n",pTree->m_ppcode[rca.m_nIndex]);
            }
        }
        //---------
        if(pbuff!=NULL)
            free(pbuff);
        //------
        fclose(infp);
        fclose(outfp);
    }
}
//----------
