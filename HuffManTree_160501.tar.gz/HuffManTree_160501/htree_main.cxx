//-----------
#include"app.h"
#include"HuffManTree.h"
//----------
void HuffManTree_Func_map()
{
    const char encode_infname[]="encode_indata.txt";
    const char encode_outfname[]="encode_outdata.txt";
    HuffManTree tree;
    map<char,Char_Attribute> cmap;
    InputCharsFromFile(encode_infname,cmap);
    AllocateHuffManTreeFromMap(&tree,cmap);
    ConstructHuffManTree(&tree);
    Encode(&tree);
    TextEncode(&tree,cmap,encode_infname,encode_outfname);
    //---------
    const char decode_infname[]="encode_outdata.txt";
    const char decode_outfname[]="decode_outdata.txt";
    TextDecode(&tree,decode_infname,decode_outfname);
    //----------
    DestroyHuffManTreeFromMap(&tree);
}
//-------------
int main()
{
        HuffManTree_Func_map();
	//------
	return 0;
}
//---------

