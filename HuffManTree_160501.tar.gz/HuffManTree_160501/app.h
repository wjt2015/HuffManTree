/*
app.h
*/
#ifndef _APP_H_
#define _APP_H_
//--------------------
#include<cstdio>
#include<cstdlib>
#include<cstring>
//---
#include<map>
//---
using namespace std;
//-------------
#define _SUCCESS_ 0
#define _FAIL_ (-1)
//---
#define _NBUFFSIZE_ 10
#define _NOENOUGH_ (-2)
#define _ILLEGALCODE_ (-3)
//--------
#endif//_APP_H_
