/*
HuffManTree.h
*/
#ifndef _HUFFMANTREE_H_
#define _HUFFMANTREE_H_
//------------
#include"app.h"
#include"PriorityQueue.h"
//-------------
typedef struct xHuffManTree
{
	int m_ncount;
	int* m_pw;//size==2*m_ncount-1;
        char* m_pc;//各个字符；
	int* m_leftID;
	int* m_rightID;
	int* m_parentID;
        char** m_ppcode;
}HuffManTree,*PHuffManTree;
//------
struct Char_Attribute
{
    int m_ncount;
    int m_nIndex;
};
//-----------
//从文件infname内读取字符数据：
void InputCharsFromFile(const char infname[],map<char,Char_Attribute>& cmap);
//-----------
//根据cmap提供的信息为哈夫曼树分配堆内存:
void AllocateHuffManTreeFromMap(PHuffManTree pTree,map<char,Char_Attribute>& cmap);
//释放哈夫曼树的堆内存:
void DestroyHuffManTreeFromMap(PHuffManTree pTree);
//----------------
//构造哈夫曼树：
void ConstructHuffManTree(PHuffManTree pTree);
//-----------
//根据构造出的哈夫曼树为每个字符编码；
void Encode(const PHuffManTree pTree);
//---------
//从文件infname内读取文本字符，编码，并将生成的0-1串写入文件outfname内;
void TextEncode(const PHuffManTree pTree,map<char,Char_Attribute>& cmap,const char infname[],const char outfname[]);
//----------
/*根据一个给定的0-1字符串译码，若成功，返回相应字符在pTree->m_pc数组内的下标，
否则，返回失败原因；*/
int Decode(const PHuffManTree pTree,char* pbuff,int* pncount);
/*
从文件infname内读取0-1串，译码,并将结果写入文件outfname内；
*/
void TextDecode(const PHuffManTree pTree,const char infname[],const char outfname[]);
//-------------
#endif//_HUFFMANTREE_H_
//-------------



